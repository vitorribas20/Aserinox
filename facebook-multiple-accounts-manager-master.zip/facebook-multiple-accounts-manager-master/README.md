## Installation

* Run the following command in terminal:

```bash
git clone https://github.com/aradhyamakkar97/facebook-multiple-accounts-manager 
cd facebook-multiple-accounts-manager 
brew install phantomjs
pip3 install selenium
```

## Running

* Run the following command in terminal:

```bash
cd facebook-multiple-accounts-manager
python3 main.py
```
